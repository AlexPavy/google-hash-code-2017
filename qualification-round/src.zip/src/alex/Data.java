package alex;

public class Data {

    public int V;
    public int E;


}
